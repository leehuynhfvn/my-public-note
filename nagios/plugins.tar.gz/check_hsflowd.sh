#!/bin/bash
## Process status
STAT=`service hsflowd status | awk '{print $3}'`
if [ "$STAT" == "stopped" ]; then
 echo "CRITICAL : hsflow daemon is Offline"
 service hsflowd restart
 exit 2
elif [ "$STAT" == "running" ]; then
 echo "OK: hsflow daemon is Running"
 exit 0
else
 echo "CRITICAL : Check Error !"
 exit 2
fi
