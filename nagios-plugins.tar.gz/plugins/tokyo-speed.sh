#!/bin/bash
echo "" > tokyo-speed.txt
echo "" > singapore-details.txt
echo "" > tokyo-details.txt
SERVER=$(speedtest --list | grep Japan | head -3 | grep -v 'GLBB\|24333' | awk -F ')' '{print $1}' | head -2 2>/dev/null )
SERVER_SINGAPORE=$(speedtest --list | grep -w "(Singapore, Singapore)" | awk -F ')' '{print $1}' | head -2 2>/dev/null )
for server in $SERVER; do
        speedtest --server $server  >> tokyo-details.txt
        cat tokyo-details.txt | grep 'Upload\|Download' | awk '{print $2}' 2>/dev/null >> tokyo-speed.txt
done
for server in $SERVER_SINGAPORE; do
        speedtest --server $server >> singapore-details.txt
done

MIN=$(awk 'min=="" || $1 < min {min=$1} END{ print min}' FS="|" tokyo-speed.txt)
MIN2=$(echo $MIN | awk -F '.' '{print $1}')

if (($MIN2>=10)); then
                echo "OK - SPEEDTEST to TOKYO is: $MIN Mbps"
                exit 0
        elif (( $MIN2<10 && $MIN2>=6 )); then
                echo "WARNNING - SPEEDTEST to TOKYO is: $MIN Mbps"
                printf "%s\n" "$(<tokyo-details.txt)" "$(<singapore-details.txt)"
                exit 1
        elif (($MIN2<6)); then
                echo "CRITICAL - SPEEDTEST to TOKYO is: $MIN Mbps"
                printf "%s\n" "$(<tokyo-details.txt)" "$(<singapore-details.txt)"
                printf "%s\n" "$(<tokyo-details.txt)" "$(<singapore-details.txt)" | /usr/local/bin/sendEmail -o tls=yes -f nagios@tenten.vn -t huynhl@runsystem.net -s smtp.tenten.vn:587 -xu nagios@tenten.vn -xp Nagios@t1nt2n -u "WARNNING SPEEDTEST to TOKYO" >/dev/null 2>&1
                exit 2
        else
                echo "UNKNOWN - SOMETHINGS WENT WRONG"
                exit 3
fi

